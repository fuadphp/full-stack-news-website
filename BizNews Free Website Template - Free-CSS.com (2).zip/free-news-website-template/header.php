<!DOCTYPE html>

<?php

$con=mysqli_connect('localhost','f111562_xeber','S@123123123AZE','f111562_xeber');

?>

<html lang="en">

<head>
    <meta charset="utf-8">
    <title>BizNews - Free News Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">
    
    <?php
    if(!isset($tinfo['title']))
    {$keys='Azerbaycan,xeber,dünya,komendat.ga';}
    else
    {
        $x=explode(' ',$tinfo['title']);
        
        for($i=0;$i<count($x);$i++)
        {
            if($i==0)
            {$keys=$x[$i];}
            else
            {$keys=$x[$i].','.$keys;}
        }
    }
    
    if(!isset($tinfo['metn']))
    {
        $description='/komendat.ga,Azərbaycanda və dünyada baş verən ən son xəbərlər';
    }
    else
    {
        $metn=mb_substr($tinfo['metn'],0,150);
        $description=$metn.'...';
    }
 
 if(!isset($tinfo['cat']))
 {$cat=' ';}
 else
 {$cat=$tinfo['cat'];}
    ?>
    
    
    
    
    
    
    
      <meta name="keywords" content='<?=$keys ?>'/>
    <meta name="description" content="<?=$description ?>" />
    
    <meta name="robots" content="index,follow"/>
    <meta name="generator" content="Komendat.ga" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" /> 
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
	<meta property="fb:app_id" content="442959889239575"/>
    <meta property="og:image" content=" "/>
    <!--<meta property="og:image:secure_url" content="" /> -->
    <meta property="og:image:width" content="640" /> 
    <meta property="og:image:height" content="442" />

    <meta property="og:url" content="Komendat.ga/>
    <meta property="og:title" content='<?=$title ?>'/>
    <meta property="og:description" content='<?=$description ?>'/>
    <meta property="og:site_name" content="Komendat"/>
    <meta property="og:type" content="article"/>

    <meta property="fb:admins" content="ebilova"/>

    <!-- Schema.org markup for Google+ -->
    <meta itemprop="name" content='Azərbaycandan və dünyadan xəbərlər - Qafqazinfo.az'/>
    <meta itemprop="description" content="<?=$description ?>"/>
    <meta itemprop="image" content=" "/>

    <!-- Twitter Card data -->
    <meta name="twitter:url" content="https://komendat.ga/" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:creator" content="@komendat" />
    <meta name="twitter:title" content="<?=$title ?>" />
    <meta name="twitter:image" content=" ">       

    <meta property="article:section" content="<?=$title ?>" />
    <meta property="article:tag" content="<?=$cat ?>" />
    <meta property="article:published_time" content="" />

    
    
    




    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid d-none d-lg-block">
        <div class="row align-items-center bg-dark px-lg-5">
            <div class="col-lg-9">
                <nav class="navbar navbar-expand-sm bg-dark p-0">
                  
                </nav>
            </div>
           
        </div>
        <div class="row align-items-center bg-white py-3 px-lg-5">
            <div class="col-lg-4">
                <a href="index.php" class="navbar-brand p-0 d-none d-lg-block">
                    <h1 class="m-0 display-4 text-uppercase text-primary">Biz<span class="text-secondary font-weight-normal">News</span></h1>
                </a>
            </div>
            
        </div>
    </div>
    <!-- Topbar End -->