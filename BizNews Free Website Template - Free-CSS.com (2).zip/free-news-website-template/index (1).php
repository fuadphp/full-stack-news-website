<?php

$con=mysqli_connect('localhost','f111562_xeber','S@123123123AZE','f111562_xeber');
include"header.php";
?>



    <!-- Navbar Start -->
    <?php include"menu.php"; ?>
    <!-- Navbar End -->


    <!-- Main News Slider Start -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-7 px-0">
                <div class="owl-carousel main-carousel position-relative">
                    
                    <?php
                    $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 0,3");
                    while($info=mysqli_fetch_array($sec))
                    {
                        
                        echo'
                          <div class="position-relative overflow-hidden" style="height: 500px;">
                        <img class="img-fluid h-100"  src="'.$info['image'].'" style="object-fit: cover;">
                        <div class="overlay">
                            <div class="mb-2">
                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                    href="single.php?id='.$info['id'].'">'.$info['cat'].'</a>
                                <a class="text-white" href="single.php?id='.$info['id'].'">'.$info['tarix'].'</a>
                            </div>
                            <a class="h2 m-0 text-white text-uppercase font-weight-bold" href="single.php?id='.$info['id'].'" title="'.$info['title'].'">'.$info['title'].'</a>
                        </div>
                    </div>';
                    }
                ?>
                </div>
            </div>
            
            
            <div class="col-lg-5 px-0">
                <div class="row mx-0">
                    <?php
                    $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 3,4");
                    while($info=mysqli_fetch_array($sec))
                    {
                        $title=mb_substr($info['title'],0,60);
                    echo'
                    <div class="col-md-6 px-0">
                        <div class="position-relative overflow-hidden" style="height: 250px;">
                            <img class="img-fluid w-100 h-100 style="width:100px; height:100px;" src="'.$info['image'].'" style="object-fit: cover;">
                            <div class="overlay">
                                <div class="mb-2">
                                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                        href="single.php?id='.$info['id'].'">'.$info['cat'].'</a>
                                    <a class="text-white" href="single.php?id='.$info['id'].'"><small>'.$info['tarix'].'</small></a>
                                </div>
                                <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="single.php?id='.$info['id'].'" title="'.$info['title'].'">'.$title.'...</a>
                            </div>
                        </div>
                    </div>';
                    }
                    ?>
                    
                    
                    
                </div>
            </div>
        </div>
    </div>
    <!-- Main News Slider End -->


    <!-- Breaking News Start -->
    <div class="container-fluid bg-dark py-3 mb-3">
        <div class="container">
            <div class="row align-items-center bg-dark">
                <div class="col-12">
                    <div class="d-flex justify-content-between">
                        <div class="bg-primary text-dark text-center font-weight-medium py-2" style="width: 170px;">Son Xeber</div>
                        <div class="owl-carousel tranding-carousel position-relative d-inline-flex align-items-center ml-3"
                            style="width: calc(100% - 170px); padding-right: 90px;">
                            <?php
                            $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 7,2");
                    while($info=mysqli_fetch_array($sec))
                    {
                       
                     
                    echo'
                            
                            <div class="text-truncate"><a class="text-white text-uppercase font-weight-semi-bold" href="single.php?id='.$info['id'].'" title="'.$info['title'].'">'.$info['title'].'</a></div>';}
                         ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
    <!-- Breaking News End -->


    <!-- Featured News Slider Start -->
    <div class="container-fluid pt-5 mb-3">
        <div class="container">
            <div class="section-title">
                <h4 class="m-0 text-uppercase font-weight-bold">SON XEBER</h4>
            </div>
            <div class="owl-carousel news-carousel carousel-item-4 position-relative">
                
                <?php
                 $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 9,4");
                    while($info=mysqli_fetch_array($sec))
                    {
                        $tarix=explode(' ',$info['tarix']);
                    echo'
                
                <div class="position-relative overflow-hidden" style="height: 300px;">
                    <img class="img-fluid h-100 style="width:100px; height:100px;"" src="'.$info['image'].'" style="object-fit: cover;">
                    <div class="overlay">
                        <div class="mb-2">
                            <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                href="single.php?id='.$info['id'].'">'.$info['cat'].'</a>
                            <a class="text-white" href="single.php?id='.$info['id'].'"><small>'.$tarix[0].'</small></a>
                        </div>
                        <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="single.php?id='.$info['id'].'">'.$info['title'].'</a>
                    </div>
                </div>';}
                
                ?>
                
                
                
               
               
                
            </div>
        </div>
    </div>
    <!-- Featured News Slider End -->


    <!-- News With Sidebar Start -->
    <div class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-12">
                            <div class="section-title">
                                <h4 class="m-0 text-uppercase font-weight-bold">Kohne Xeberler</h4>
                                <a class="text-secondary font-weight-medium text-decoration-none" href="">Hamisini gor</a>
                            </div>
                        </div>
                        
                         <?php
                           $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 13,4");
                    while($info=mysqli_fetch_array($sec))
                    {$title=mb_substr($info['title'],0,40);
                    echo'  <div class="col-lg-6">
                            <div class="position-relative mb-3">
                                <img class="img-fluid w-100"  style="height:250px;" src="'.$info['image'].'" style="object-fit: cover;">
                                <div class="bg-white border border-top-0 p-4">
                                    <div class="mb-2">
                                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                            href="single.php?id='.$info['id'].'">'.$info['cat'].'</a>
                                        <a class="text-body" href=""><small>'.$info['tarix'].'</small></a>
                                    </div>
                                    <a class="h4 d-block mb-3 text-secondary text-uppercase font-weight-bold" href="single.php?id='.$info['id'].'">'.$title.'...</a>
                                    <p class="m-0"></p>
                                </div>
                                <div class="d-flex justify-content-between bg-white border border-top-0 p-4">
                                    <div class="d-flex align-items-center">
                                        <img class="rounded-circle mr-2" src="img/user.jpg" width="25" height="25" alt="">
                                        <small>'.$info['menbe'].'</small>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <small class="ml-3"><i class="far fa-eye mr-2"></i>12345</small>
                                        <small class="ml-3"><i class="far fa-comment mr-2"></i>123</small>
                                    </div>
                                </div>
                            </div>
                            </div>
                            ';}
                          ?>
                          
                          
                          <div class="col-lg-6">
                              <?php
                              $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 17,2");
                    while($info=mysqli_fetch_array($sec))
                    {
                        $tarix=explode(' ',$info['tarix']);
                    echo'
                            <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                <img style="width:100px; height:110px;" class="img-fluid" src="'.$info['image'].'" alt="">
                                <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                    <div class="mb-2">
                                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="single.php?id='.$info['id'].'">'.$info['cat'].'</a>
                                        <a class="text-body" href=""><small>'.$tarix[0].'</small></a>
                                    </div>
                                    <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="single.php?id='.$info['id'].'" style="font-size:13px;">'.$info['title'].'</a>
                                </div>
                            </div>';}
                            ?>
                            
                          
                            
                            
                            
                        </div>
                        <div class="col-lg-6">
                            
                            
                            <?php
                            $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 19,2");
                    while($info=mysqli_fetch_array($sec))
                    { $tarix= explode(' ',$info['tarix']);
                   
                    echo'
                   
                    
                            
                            
                            <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                <img style="width:110px; height:110px;" class="img-fluid" src="'.$info['image'].'" alt="">
                                <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                    <div class="mb-2">
                                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="single.php?id='.$info['id'].'">'.$info['cat'].'</a>
                                        <a class="text-body" href=""><small>'.$tarix[0].'</small></a>
                                    </div>
                                    <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="single.php?id='.$info['id'].'" style="font-size:13px;">'.$info['title'].'</a>
                                </div>
                            </div>';}
                            ?>
                            
                            
                        </div>
                        
                      
                        
                    
                          
                            

                           
                           
                     
                        
                        
                        <div class="col-lg-12">
                            <?php
                            $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 21,1");
                    while($info=mysqli_fetch_array($sec))
                    {echo'
                            
                            <div class="row news-lg mx-0 mb-3">
                                <div class="col-md-6 h-100 px-0">
                                    <img class="img-fluid h-100 style="width:100px; height:100px;"" src="'.$info['image'].'" style="object-fit: cover;">
                                </div>
                                <div class="col-md-6 d-flex flex-column border bg-white h-100 px-0">
                                    <div class="mt-auto p-4">
                                        <div class="mb-2">
                                            <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                                href="single.php?id='.$info['id'].'"></a>
                                            <a class="text-body" href="single.php?id='.$info['id'].'"><small>'.$info['tarix'].'</small></a>
                                        </div>
                                        <a class="h4 d-block mb-3 text-secondary text-uppercase font-weight-bold" href="single.php?id='.$info['id'].'">'.$info['title'].'</a>
                                        <p class="m-0">metn</p>
                                    </div>
                                    <div class="d-flex justify-content-between bg-white border-top mt-auto p-4">
                                        <div class="d-flex align-items-center">
                                            <img class="rounded-circle mr-2" src="img/user.jpg" width="25" height="25" alt="">
                                            <small>'.$info['menbe'].'</small>
                                        </div>
                                        <div class="d-flex align-items-center">
                                            <small class="ml-3"><i class="far fa-eye mr-2"></i>12345</small>
                                            <small class="ml-3"><i class="far fa-comment mr-2"></i>123</small>
                                        </div>
                                    </div>
                                </div>
                            </div>';}
                            ?>
                            
                        </div>
                        
                        
                        
                        
                        
                         <div class="col-lg-6">
                        <?php
                        $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 22,2");
                    while($info=mysqli_fetch_array($sec))
                    {
                        
                        $title = mb_substr($info['title'],0,49);
                        $tarix = explode(' ',$info['tarix']);
                    
                    
                    echo'
                           
                            <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                <img style="wight:110px; height:110px;" class="img-fluid" src="'.$info['image'].'" alt="">
                                <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                    
                                 
                                    
                                    <div class="mb-2">
                                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="single.php?id='.$info['id'].'">'.$info['cat'].'</a>
                                        <a class="text-body" href=""><small>'.$tarix[0].'</small></a>
                                    </div>
                                    <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="single.php?id='.$info['id'].'" style="font-size:13px;">'.$title.'...</a>
                                </div>
                            </div>';}
                            ?>
                         
                            
                        </div>
                        
                        
                        
                        <div class="col-lg-6">
                            
                            <?php
                            $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 24,2");
                    while($info=mysqli_fetch_array($sec))
                    { $title=mb_substr($info['title'],0,49);
                    $tarix=explode(' ',$info['tarix']);
                                echo'
                   
                            
                            <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                <img style="width:110px; height:110px;" class="img-fluid" src="'.$info['image'].'" alt="">
                                <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                    <div class="mb-2">
                                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="single.php?id='.$info['id'].'">'.$info['cat'].'</a>
                                        <a class="text-body" href="single.php?id='.$info['id'].'"><small>'.$tarix[0].'</small></a>
                                    </div>
                                    <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="single.php?id='.$info['id'].'">'.$title.'...</a>
                                </div>
                            </div>';}
                            ?>
                            
                           
                        </div>
                        
                    </div>
                       
                </div>
                
                <div class="col-lg-4">
                    <!-- Social Follow Start -->
                   
                    <!-- Social Follow End -->

                    <!-- Ads Start -->
                  
                    <!-- Ads End -->

                    <!-- Popular News Start -->
                    <div class="mb-3">
                        <div class="section-title mb-0">
                            <h4 class="m-0 text-uppercase font-weight-bold">Trend Xeberler</h4>
                        </div>
                        
                        
                        <?php
                         $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 26,10");
                    while($info=mysqli_fetch_array($sec))
                    { $title=mb_substr($info['title'],0,49);
                    $tarix=explode(' ',$info['tarix']);
                                echo'
                        
                        <div class="bg-white border border-top-0 p-3">
                            <div class="d-flex align-items-center bg-white mb-3" style="height: 114px;">
                                <img  class="img-fluid" style="width:110px; height:90px;"src="'.$info['image'].'" alt="">
                                <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                    <div class="mb-2">
                                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="single.php?id='.$info['id'].'">'.$info['cat'].'</a>
                                        <a class="text-body" href=""><small>'.$tarix[0].'</small></a>
                                    </div>
                                    <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="single.php?id='.$info['id'].'">'.$title.'...</a>
                                </div>
                            </div>
                            </div>';}
                        ?>
                        
                        
                        
                    </div>
                    <!-- Popular News End -->

                 

                   
                    <!-- Tags End -->
                </div>
            </div>
        </div>
    </div>
    <!-- News With Sidebar End -->


    
               
           
          
        </div>
    </div>
    <div class="container-fluid py-4 px-sm-3 px-md-5" style="background: #111111;">
        <p class="m-0 text-center">&copy; <a href="#">www.komendat.ga</a>. All Rights Reserved. 
		
		<!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
	Programmed by Fuad Gasimzade</p>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary btn-square back-to-top"><i class="fa fa-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>