
<?php
$con=mysqli_connect('localhost','f111562_xeber','S@123123123AZE','f111562_xeber');
?>

<div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-2 py-lg-0 px-lg-5">
            <a href="index.php" class="navbar-brand d-block d-lg-none">
                <h1 class="m-0 display-4 text-uppercase text-primary">Biz<span class="text-white font-weight-normal">News</span></h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-0 px-lg-3" id="navbarCollapse">
                <div class="navbar-nav mr-auto py-0">
                    <a href="index.php" class="nav-item nav-link active">Baş Səhifə</a>
                    <?php
                    
                    $sec=mysqli_query($con,"SELECT cat FROM xeber WHERE cat IN ('Kriminal','Dünya','Siyasət','İDMAN','İQTİSADİYYAT') GROUP BY cat");
                    while($info=mysqli_fetch_array($sec))
                    {echo'
                    
                    <a href="cat.php?cat='.$info['cat'].'" class="nav-item nav-link">'.$info['cat'].'</a>';}
                    ?>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Digər</a>
                        <div class="dropdown-menu rounded-0 m-0">
                           <?php
                    
                    $sec=mysqli_query($con,"SELECT cat FROM xeber WHERE cat NOT IN ('Kriminal','Dünya','Siyasət','İDMAN','İQTİSADİYYAT') GROUP BY cat");
                    while($info=mysqli_fetch_array($sec))
                    {echo'
                    
                    <a href="cat.php?cat='.$info['cat'].'" class="nav-item nav-link">'.$info['cat'].'</a>';}
                    ?>
                        </div>
                    </div>
                    <a href="#" class="nav-item nav-link">HAQQINDA</a>
                   
                    <a href="contact.php" class="nav-item nav-link">ƏLAQƏ</a>
                </div>
                <div class="input-group ml-auto d-none d-lg-flex" style="width: 100%; max-width: 300px;">
                    <input type="text" class="form-control border-0" placeholder="Axtar">
                    <div class="input-group-append">
                        <button class="input-group-text bg-primary text-dark border-0 px-3"><i
                                class="fa fa-search"></i></button>
                    </div>
                </div>
            </div>
        </nav>
    </div>