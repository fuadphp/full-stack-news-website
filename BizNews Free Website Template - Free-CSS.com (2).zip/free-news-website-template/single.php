

<?php
$con=mysqli_connect('localhost','f111562_xeber','S@123123123AZE','f111562_xeber');

$tsec=mysqli_query($con,"SELECT * FROM xeber WHERE id='".$_GET['id']."'");
if(mysqli_num_rows($tsec)>0)
{
$tinfo=mysqli_fetch_array($tsec);}
else
{echo'<meta http-equiv="refresh" content="0; URL=index.php">';exit;}

include"header.php";

?>

<!DOCTYPE html>



    <!-- Navbar Start -->
    <?php include'menu.php'; 
    ?>
    <!-- Navbar End -->


   <!-- Breaking News Start -->
    <div class="container-fluid mt-5 mb-3 pt-3">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12">
                    <div class="d-flex justify-content-between">
                        <div class="section-title border-right-0 mb-0" style="width: 180px;">
                            <h4 class="m-0 text-uppercase font-weight-bold">Tranding</h4>
                        </div>
                        <div class="owl-carousel tranding-carousel position-relative d-inline-flex align-items-center bg-white border border-left-0"
                            style="width: calc(100% - 180px); padding-right: 100px;">
                            
                            <?php
                            $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 0,3");
                            while($info=mysqli_fetch_array($sec))
                            {echo'
                            <div class="text-truncate"><a class="text-secondary text-uppercase font-weight-semi-bold" href="">'.$info['title'].'</a></div>';}
                            ?>
                           
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breaking News End -->



    <!-- News With Sidebar Start -->
    <div class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <!-- News Detail Start -->
                    <div class="position-relative mb-3">
                        <img class="img-fluid w-100" src="<?=$tinfo['image'] ?>" style="object-fit: cover;">
                        <div class="bg-white border border-top-0 p-4">
                            <div class="mb-3">
                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                    href="">Business</a>
                                <a class="text-body" href="">Jan 01, 2045</a>
                            </div>
                            <h1 class="mb-3 text-secondary text-uppercase font-weight-bold"> <?=$tinfo['title'] ?></h1>
                            <p><?=$tinfo['metn'] ?></p>
                        </div>
                        <div class="d-flex justify-content-between bg-white border border-top-0 p-4">
                           
                        </div>
                        
                        
                        
                    <!-- Comment List Start -->
                    <div class="mb-3">
                        
                        
                    </div>
                    <!-- Comment List End -->

                   
                </div>

                <div class="col-lg-4">
                    <!-- Social Follow Start -->
                    <div class="mb-3">
                        
                        
                    </div>
                    <!-- Social Follow End -->

                    <!-- Ads Start -->
                   
                    <!-- Ads End -->

                    <!-- Popular News Start -->
                    <div class="mb-3">
                        <div class="section-title mb-0">
                            <h4 class="m-0 text-uppercase font-weight-bold">Trend Xəbərlər</h4>
                        </div>
                        <div class="bg-white border border-top-0 p-3">
                           
                            <?php
                            $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 0,1");
                            while($info=mysqli_fetch_array($sec))
                            {
                                $title=mb_substr($info['title'], 0,49);
                                $tarix=explode(' ',$info['tarix']);
                            
                            echo'
                            <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                <img class="img-fluid" style="width:110px; height:110px;" src="'.$info['image'].'" alt="">
                                <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                    <div class="mb-2">
                                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">'.$info['cat'].'</a>
                                        <a class="text-body" href=""><small>'.$tarix[0].'</small></a>
                                    </div>
                                    <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">'.$title.'...</a>
                                </div>
                            </div>';}
                            ?>
                            
                            
                            
                                                        <?php
                            $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 1,1");
                            while($info=mysqli_fetch_array($sec))
                            {
                                $title=mb_substr($info['title'], 0,49);
                                $tarix=explode(' ',$info['tarix']);
                            
                            echo'
                            <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                <img class="img-fluid" style="width:110px; height:110px;" src="'.$info['image'].'" alt="">
                                <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                    <div class="mb-2">
                                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">'.$info['cat'].'</a>
                                        <a class="text-body" href=""><small>'.$tarix[0].'</small></a>
                                    </div>
                                    <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">'.$title.'...</a>
                                </div>
                            </div>';}
                            ?>
                            
                            
                                                        <?php
                            $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 2,1");
                            while($info=mysqli_fetch_array($sec))
                            {
                                $title=mb_substr($info['title'], 0,49);
                                $tarix=explode(' ',$info['tarix']);
                            
                            echo'
                            <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                <img class="img-fluid" style="width:110px; height:110px;" src="'.$info['image'].'" alt="">
                                <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                    <div class="mb-2">
                                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">'.$info['cat'].'</a>
                                        <a class="text-body" href=""><small>'.$tarix[0].'</small></a>
                                    </div>
                                    <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">'.$title.'...</a>
                                </div>
                            </div>';}
                            ?>
                            
                                                        <?php
                            $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 3,1");
                            while($info=mysqli_fetch_array($sec))
                            {
                                $title=mb_substr($info['title'], 0,49);
                                $tarix=explode(' ',$info['tarix']);
                            
                            echo'
                            <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                <img class="img-fluid" style="width:110px; height:110px;" src="'.$info['image'].'" alt="">
                                <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                    <div class="mb-2">
                                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">'.$info['cat'].'</a>
                                        <a class="text-body" href=""><small>'.$tarix[0].'</small></a>
                                    </div>
                                    <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">'.$title.'...</a>
                                </div>
                            </div>';}
                            ?>
                            
                            
                                                        <?php
                            $sec=mysqli_query($con,"SELECT * FROM xeber ORDER BY id DESC LIMIT 4,1");
                            while($info=mysqli_fetch_array($sec))
                            {
                                $title=mb_substr($info['title'], 0,49);
                                $tarix=explode(' ',$info['tarix']);
                            
                            echo'
                            <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                                <img class="img-fluid" style="width:110px; height:110px;" src="'.$info['image'].'" alt="">
                                <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                    <div class="mb-2">
                                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">'.$info['cat'].'</a>
                                        <a class="text-body" href=""><small>'.$tarix[0].'</small></a>
                                    </div>
                                    <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">'.$title.'...</a>
                                </div>
                            </div>';}
                            ?>
                            

                            
                        </div>
                    </div>
                    <!-- Popular News End -->

                    <!-- Newsletter Start -->
                    
                    <!-- Newsletter End -->

                    
                </div>
            </div>
        </div>
    </div>
    <!-- News With Sidebar End -->


    
    <div class="container-fluid py-4 px-sm-3 px-md-5" style="background: #111111;">
        <p class="m-0 text-center">&copy; <a href="#">www.komendat.ga</a>. All Rights Reserved. 
		
		<!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
		Programmed by Fuad Gasimzade</p>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary btn-square back-to-top"><i class="fa fa-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>