<?php
session_start();
?>
<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <title>BizNews - Free News Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid d-none d-lg-block">
        <div class="row align-items-center bg-dark px-lg-5">
          
            <div class="col-lg-3 text-right d-none d-md-block">
               
            </div>
        </div>
        <div class="row align-items-center bg-white py-3 px-lg-5">
            <div class="col-lg-4">
                <a href="index.php" class="navbar-brand p-0 d-none d-lg-block">
                    <h1 class="m-0 display-4 text-uppercase text-primary">Biz<span class="text-secondary font-weight-normal">News</span></h1>
                </a>
            </div>
            
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
<?php include"menu.php"; ?>
    <!-- Navbar End -->


    <!-- Contact Start -->
    <div class="container-fluid mt-5 pt-7">
        <div class="container">
            <div class="row">
                <div class="col-lg-18">
                    <div class="section-title mb-0">
                        <h4 class="m-0 text-uppercase font-weight-bold">Bizimlə əlaqə saxlayın!</h4>
                    </div>
                    <div class="bg-white border border-top-0 p-4 mb-4">
                        <div class="mb-4">
                            <h6 class="text-uppercase font-weight-bold">Haqqımızda</h6>
                            
                            <p class="mb-4">
                                      ------------------------------------------------------------------------------------------------------------------------------------------------ .</p>
							<div class="mb-3">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="fa fa-map-marker-alt text-primary mr-2"></i>
                                    <h6 class="font-weight-bold mb-0">Filialımız</h6>
                                </div>
                                <p class="m-0">Bakı Şəhəri,Binəqədi r-nu, Svetlana Məmmədova küç. 107</p>
                            </div>
                            <div class="mb-3">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="fa fa-envelope-open text-primary mr-2"></i>
                                    <h6 class="font-weight-bold mb-0">Email</h6>
                                </div>
                                <p class="m-0">fuadqasimzade14@gmail.com</p>
                            </div>
                            <div class="mb-3">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="fa fa-phone-alt text-primary mr-2"></i>
                                    <h6 class="font-weight-bold mb-0">Əlaqə</h6>
                                </div>
                                <p class="m-0">+994517801410</p>
                            </div>
                        </div>
                        <h6 class="text-uppercase font-weight-bold mb-3">Bizimlə Əlaqə</h6>
                        
                        <?php
                        $tarix=date('Y-m-d H:i:s');
                        $con=mysqli_connect('localhost','f111562_xeber','S@123123123AZE','f111562_xeber');
                        if(isset($_POST['gonder']))
                        {
                        if($_SESSION['token']==$_POST['token'])
                        {
                        
                        $ins=mysqli_query($con,"INSERT INTO contact(ad,email,kime,mesaj,tarix)
                        VALUES('".$_POST['ad']."','".$_POST['email']."','".$_POST['kime']."','".$_POST['mesaj']."','".$tarix."')");
                    
                     
                        
                        if($ins==true)
                        {echo'<div class="alert alert-secondary" role="alert">Melumatiniz ugurla gonderildi</div>';}
                        else
                        {echo'<div class="alert alert-danger" role="alert">Melumatiniz gonderilmedi</div>';}
                         
                            
                        }
                        }
                        
                          $_SESSION['token'] = md5(time());
                          ?>
                          
                        <form method="POST">
                            <input type="hidden" name="token" value="<?=$_SESSION['token'] ?>">
                            
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        
                            
                                        <input type="text" name="ad" class="form-control p-4" placeholder="Adınız" required="required"/>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="email" name="email" class="form-control p-4" placeholder="Email ünvanı " required="required"/>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" name="kime" class="form-control p-4" placeholder="Kimə" required="required"/>
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" name="mesaj" "rows="4" placeholder="Mesaj" required="required"></textarea>
                            </div>
                            <div>
                                <button class="btn btn-primary font-weight-semi-bold px-4" style="height: 50px;"
                                    type="submit" name="gonder" value="gonder">Göndər</button>
                            </div>
                        </form>
                     
                       
                    </div>
                </div>
                <div class="col-lg-4">
                    <!-- Social Follow Start -->
                    
                        
                    <!-- Social Follow End -->

                    <!-- Newsletter Start -->
                    
                    <!-- Newsletter End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Contact End -->

    <!-- Footer Start -->
   
    <div class="container-fluid py-4 px-sm-3 px-md-5" style="background: #111111;">
        <p class="m-0 text-center">&copy; <a href="#">www.komendat.ga</a>. All Rights Reserved. 
		
		<!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
		Programmed by Fuad Gasimzade</p>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary btn-square back-to-top"><i class="fa fa-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>